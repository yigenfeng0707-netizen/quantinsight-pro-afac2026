// 试用账号活动查询：经线上真实路径（admin → 管理后台 → 登录历史）读取服务器最新数据
import { chromium } from "playwright";
const BASE = "https://gsym236998-quantinsight-pro.ms.show";
const TRIALS = ["xiaozs", "xuezg", "qiuph", "hehx", "zhangjt", "chenls"];
const b = await chromium.launch({ headless: true });
const ctx = await b.newContext({ viewport: { width: 1600, height: 900 } });
const page = await ctx.newPage();
page.setDefaultTimeout(60000);
const wait = (ms) => new Promise(r => setTimeout(r, ms));

await page.goto(BASE, { waitUntil: "load" });
await wait(25000);
// ms.show 页面是 iframe 壳，进 app frame 操作
let app = null;
for (let i = 0; i < 10 && !app; i++) {
  for (const f of page.frames()) {
    try {
      if ((await f.locator('input[data-testid="stTextInputField"]').count()) > 0) { app = f; break; }
    } catch (e) {}
  }
  if (!app) await wait(5000);
}
if (!app) { console.log("APP_FRAME_NOT_FOUND"); process.exit(1); }
await app.locator('input[data-testid="stTextInputField"]:visible').first().fill("admin");
await app.locator('input:visible[type="password"]').nth(0).fill("QIyrd2026demo");
await app.getByRole("button", { name: /登录/ }).last().click();
await wait(15000);
console.log("LOGIN:", (await app.locator("body").innerText()).includes("选择功能模块") ? "ok" : "FAIL");

await wait(10000);
let clicked = false;
for (const sel of ['label:has-text("管理后台")', 'text=⚙️ 管理后台', 'text=管理后台']) {
  try {
    const el = app.locator(sel).first();
    if ((await el.count()) > 0) { await el.click({ timeout: 15000 }); clicked = true; break; }
  } catch (e) {}
}
if (!clicked) console.log("ADMIN_ENTRY_FAIL");
await wait(20000);
await app.getByRole("tab", { name: /登录历史/ }).click().catch(() => console.log("TAB_FAIL"));
await wait(15000);
const t = await app.locator("body").innerText();
console.log("=== 试用账号登录记录（服务器实时）===");
for (const u of TRIALS) {
  const m = t.match(new RegExp(u + "[^\\n]{0,60}", "g"));
  console.log(u, "=>", m ? m.slice(0, 2).join(" | ") : "无记录");
}
await page.screenshot({ path: "../_local_shots/trial_usage_1116.png" });
await b.close();
console.log("CHECK_DONE");
