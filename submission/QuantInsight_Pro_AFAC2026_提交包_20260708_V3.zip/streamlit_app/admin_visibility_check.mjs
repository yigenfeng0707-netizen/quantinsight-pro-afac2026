// A3 前置验证：admin 登录在线 Demo → 管理后台 → 使用统计截图（证明按用户可见）
import { chromium } from "playwright";
import fs from "fs";

const BASE = "http://121.196.102.54";
const OUT = "../_local_shots";
fs.mkdirSync(OUT, { recursive: true });
const wait = (ms) => new Promise(r => setTimeout(r, ms));

const b = await chromium.launch({ headless: true });
const ctx = await b.newContext({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1.5 });
const page = await ctx.newPage();
page.setDefaultTimeout(60000);

await page.goto(BASE, { waitUntil: "load" });
await wait(10000);
await page.locator('input[placeholder="请输入用户名"]').fill("admin");
await page.locator('input[placeholder="请输入密码"]').fill(process.env.ADMIN_PW || "QIyrd2026demo");
await page.getByRole("button", { name: /登录/ }).last().click();
await wait(12000);
const ok = (await page.locator("body").innerText()).includes("选择功能模块");
console.log("ADMIN_LOGIN:", ok ? "ok" : "FAIL");
console.log("HAS_ADMIN_TAB:", (await page.locator("body").innerText()).includes("管理后台") ? "yes" : "no");

// 进入管理后台
await page.locator('label:has-text("⚙️ 管理后台")').first().click({ timeout: 15000 });
await wait(12000);
let t = await page.locator("body").innerText();
console.log("DASH_HAS_USAGE:", t.includes("使用统计") || t.includes("使用情况") ? "yes" : "no");
console.log("DASH_HAS_USERS:", ["xiaozs", "xuezg", "qiuph", "hehx", "zhangjt", "chenls"].filter(u => t.includes(u)).join(","));

await page.screenshot({ path: `${OUT}/admin_usage_1.png` });
// 若有「使用统计」子页签则进入再截一张
try {
  await page.getByRole("tab", { name: /使用统计/ }).click({ timeout: 8000 });
  await wait(10000);
  t = await page.locator("body").innerText();
  console.log("ANALYTICS_USERS:", ["xiaozs", "xuezg", "qiuph", "hehx", "zhangjt", "chenls"].filter(u => t.includes(u)).join(","));
  await page.screenshot({ path: `${OUT}/admin_usage_2.png` });
} catch { console.log("NO_ANALYTICS_TAB"); }
await b.close();
console.log("CHECK_DONE");
