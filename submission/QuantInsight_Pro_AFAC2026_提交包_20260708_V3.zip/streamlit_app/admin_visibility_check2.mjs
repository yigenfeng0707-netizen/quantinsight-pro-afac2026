// 管理后台可见性复验：等足渲染 → 用户分析页签 → 找试用用户名
import { chromium } from "playwright";
import fs from "fs";

const BASE = "http://121.196.102.54";
const OUT = "../_local_shots";
const wait = (ms) => new Promise(r => setTimeout(r, ms));

const b = await chromium.launch({ headless: true });
const ctx = await b.newContext({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1.5 });
const page = await ctx.newPage();
page.setDefaultTimeout(60000);

await page.goto(BASE, { waitUntil: "load" });
await wait(10000);
await page.locator('input[placeholder="请输入用户名"]').fill("admin");
await page.locator('input[placeholder="请输入密码"]').fill("QIyrd2026demo");
await page.getByRole("button", { name: /登录/ }).last().click();
await wait(14000);
await page.locator('label:has-text("⚙️ 管理后台")').first().click();
await wait(20000);
let t = await page.locator("body").innerText();
console.log("DASH_READY:", t.includes("用户分析") || t.includes("用户增长") ? "yes" : "no");

await page.getByRole("tab", { name: /用户分析/ }).click({ timeout: 10000 }).catch(() => console.log("TAB_FAIL"));
await wait(15000);
t = await page.locator("body").innerText();
const found = ["xiaozs", "xuezg", "qiuph", "hehx", "zhangjt", "chenls"].filter(u => t.includes(u));
console.log("ANALYTICS_USERS:", found.length ? found.join(",") : "NONE");
console.log("REG_TABLE:", t.includes("注册时间") || t.includes("最近登录") ? "yes" : "no");
await page.screenshot({ path: `${OUT}/admin_usage_3.png`, fullPage: false });
await b.close();
console.log("CHECK2_DONE");
