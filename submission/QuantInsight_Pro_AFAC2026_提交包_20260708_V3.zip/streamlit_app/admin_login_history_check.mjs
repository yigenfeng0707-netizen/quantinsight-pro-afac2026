// 登录历史页签直接证据：应看到 6 个试用账号的今天登录记录
import { chromium } from "playwright";
import fs from "fs";
const BASE = "http://121.196.102.54";
const OUT = "../_local_shots";
const wait = (ms) => new Promise(r => setTimeout(r, ms));

const b = await chromium.launch({ headless: true });
const ctx = await b.newContext({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1.5 });
const page = await ctx.newPage();
page.setDefaultTimeout(60000);
await page.goto(BASE, { waitUntil: "load" });
await wait(10000);
await page.locator('input[placeholder="请输入用户名"]').fill("admin");
await page.locator('input[placeholder="请输入密码"]').fill("QIyrd2026demo");
await page.getByRole("button", { name: /登录/ }).last().click();
await wait(14000);
await page.locator('label:has-text("⚙️ 管理后台")').first().click();
await wait(20000);
await page.getByRole("tab", { name: /登录历史/ }).click({ timeout: 10000 });
await wait(15000);
const t = await page.locator("body").innerText();
const found = ["xiaozs", "xuezg", "qiuph", "hehx", "zhangjt", "chenls"].filter(u => t.includes(u));
console.log("LOGIN_HISTORY_USERS:", found.length ? found.join(",") : "NONE", `(${found.length}/6)`);
await page.screenshot({ path: `${OUT}/admin_login_history.png`, fullPage: false });
await b.close();
console.log("CHECK3_DONE");
