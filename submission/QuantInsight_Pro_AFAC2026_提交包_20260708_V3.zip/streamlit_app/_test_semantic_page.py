"""临时冒烟页：只渲染语义目录，验证本体/前端链路。文件名匹配 _test_*.py 忽略规则。"""
import streamlit as st
from features.semantic_browser import render_semantic_browser
render_semantic_browser()
