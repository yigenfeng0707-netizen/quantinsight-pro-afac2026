// A3 前置：为试用名单在线注册 6 个账号 + 逐个登录冒烟验证（真实结果，不代填反馈）
// 运行：node register_trials.mjs [live|local]   默认 live（http://121.196.102.54）
import { chromium } from "playwright";

const BASE = process.argv[2] === "local" ? "http://127.0.0.1:8501" : "http://121.196.102.54";
// 用户名（4-20 字母数字）｜密码 = Qi# + 手机号后 6 位
const USERS = [
  { u: "xiaozs", p: "Qi#635007", who: "肖总·浙商证券" },
  { u: "xuezg",  p: "Qi#855006", who: "薛总·资管公司" },
  { u: "qiuph",  p: "Qi#193223", who: "邱先生·普华资本" },
  { u: "hehx",   p: "Qi#783668", who: "何总·华鑫证券" },
  { u: "zhangjt",p: "Qi#613474", who: "张同学·集团" },
  { u: "chenls", p: "Qi#768666", who: "陈姐·律师" },
];

const b = await chromium.launch({ headless: true });
const results = [];
const wait = (ms) => new Promise(r => setTimeout(r, ms));

for (const { u, p, who } of USERS) {
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  page.setDefaultTimeout(45000);
  const step = (m) => console.log(`[${who}#${u}] ${m}`);
  try {
    // —— 注册 ——
    await page.goto(BASE, { waitUntil: "load" });
    await wait(9000);
    if ((await page.locator("body").innerText()).includes("选择功能模块")) {
      step("SKIP_REGISTER: 已登录态（不该发生，换 context 应为访客）");
    }
    await page.getByRole("tab", { name: /注册/ }).click({ timeout: 15000 });
    await wait(1500);
    await page.locator('input[placeholder="4-20 位字母数字"]').fill(u);
    await page.locator('input[placeholder="至少 6 位"]').fill(p);
    await page.locator('input[placeholder="再次输入密码"]').fill(p);
    await page.getByRole("button", { name: "注册", exact: true }).click();
    await wait(5000);
    const regText = await page.locator("body").innerText();
    const regOk = regText.includes(`用户名: ${u}`) || regText.includes("注册成功");
    step(`REGISTER: ${regOk ? "ok" : "CHECK(" + (regText.match(/❌ [^\n]*/)?.[0] || "no-msg") + ")"} `);

    // —— 登录冒烟 ——
    await page.goto(BASE, { waitUntil: "load" });
    await wait(9000);
    const body0 = await page.locator("body").innerText();
    if (body0.includes("选择功能模块")) {
      step("ALREADY_IN"); results.push({ u, who, register: regOk, login: true }); await ctx.close(); continue;
    }
    await page.locator('input[placeholder="请输入用户名"]').fill(u);
    await page.locator('input[placeholder="请输入密码"]').fill(p);
    await page.getByRole("button", { name: /登录/ }).last().click();
    await wait(12000);
    const loginOk = (await page.locator("body").innerText()).includes("选择功能模块");
    step(`LOGIN_SMOKE: ${loginOk ? "ok" : "FAIL"}`);
    results.push({ u, who, register: regOk, login: loginOk });
  } catch (e) {
    step(`ERROR: ${String(e).slice(0, 120)}`);
    results.push({ u, who, register: false, login: false, err: String(e).slice(0, 80) });
  }
  await ctx.close();
}
await b.close();
console.log("\n===== SUMMARY =====");
for (const r of results) console.log(`${r.login ? "✅" : "❌"} ${r.u} (${r.who})  register=${r.register} login_smoke=${r.login}`);
console.log(`PASS=${results.filter(r => r.login).length}/6  REGISTER_DONE`);
