// QuantInsight Pro 全页面巡检（本地 8551）
const { chromium } = require("playwright");
const BASE = "http://localhost:8551";
const wait = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const b = await chromium.launch({ headless: true });
  const ctx = await b.newContext({ viewport: { width: 1600, height: 900 } });
  const page = await ctx.newPage();
  page.setDefaultTimeout(45000);
  const errors = [];
  page.on("pageerror", e => errors.push("PAGEERROR: " + e.message.slice(0,200)));
  page.on("console", m => { if (m.type() === "error") errors.push("CONSOLE: " + m.text().slice(0,200)); });

  await page.goto(BASE, { waitUntil: "load" });
  await page.waitForTimeout(7000);
  await page.locator('input[placeholder="请输入用户名"]').first().fill("smoketest");
  await page.locator('input[placeholder="请输入密码"]').first().fill("smoketest123");
  await page.getByRole("button", { name: /登录/ }).first().click();
  await page.waitForTimeout(9000);
  const labels = await page.locator('label:has(input[type="radio"])').allInnerTexts();
  console.log("PAGES:", labels.length);

  const results = [];
  for (const lbl of labels) {
    const errsBefore = errors.length;
    try {
      await page.locator(`label:has(input[type="radio"]):has-text("${lbl}")`).first().click();
      await page.waitForTimeout(7000);
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight)).catch(()=>{});
      await page.waitForTimeout(1500);
      const body = await page.locator("body").innerText().catch(() => "");
      const len = body.length;
      const tb = body.match(/(Traceback|AttributeError|ModuleNotFoundError|ImportError|KeyError|TypeError|IndexError|ValueError|NameError)[^\n]{0,80}/g);
      const newErrs = errors.slice(errsBefore);
      const status = (tb ? "TRACEBACK" : (newErrs.length ? "JSERR" : (len < 50 ? "EMPTY" : "OK")));
      results.push({ page: lbl, len, status, tb: tb ? tb.slice(0,2).join(";") : "", js: newErrs.length });
      console.log(`[${status}] ${lbl}  len=${len}  ${tb ? "TB: "+tb.slice(0,1).join(";") : ""} ${newErrs.length? "jsErr="+newErrs.length : ""}`);
    } catch (e) {
      console.log(`[CLICK_FAIL] ${lbl}: ${e.message.slice(0,100)}`);
      results.push({ page: lbl, status: "CLICK_FAIL" });
    }
  }
  const fs = require("fs");
  fs.writeFileSync("/tmp/qi_sweep_results.json", JSON.stringify({results, totalErrors: errors.length, errors: errors.slice(0,20)}, null, 1));
  const ok = results.filter(r => r.status === "OK").length;
  console.log(`=== SUMMARY: OK=${ok}/${results.length}  totalJSErrors=${errors.length} ===`);
  await b.close();
})();
