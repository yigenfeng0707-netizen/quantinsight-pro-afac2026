// 公网创空间全链路验证（v2）：注册新验证账号 → 登录 → AI 问答（语义对齐条）→ 核心页巡检
// 目标：https://gsym236998-quantinsight-pro.ms.show（iframe 壳，需自适应找 frame）
import { chromium } from "playwright";
import { mkdirSync } from "fs";

const BASE = "https://gsym236998-quantinsight-pro.ms.show";
const SUFFIX = Date.now().toString().slice(-5);
const USER = `verify${SUFFIX}`;
const PASS = `Verify#2026`;
const SHOT = "../_local_shots/online_verify";
mkdirSync("../_local_shots", { recursive: true });

// 找到包含指定元素的 frame（ms.show 是 iframe 壳，且登录会触发 frame 重建）
async function findFrame(page, selector, timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const f of page.frames()) {
      const n = await f.locator(selector).count().catch(() => 0);
      if (n > 0) return f;
    }
    await page.waitForTimeout(1500);
  }
  return null;
}

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
const results = [];
const ok = (name, pass, extra = "") => {
  results.push(`${pass ? "✅" : "❌"} ${name}${extra ? " — " + extra : ""}`);
  console.log(`${pass ? "PASS" : "FAIL"} ${name} ${extra}`);
};

console.log("== 1. 打开公网地址 ==");
await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 90000 });
let frame = await findFrame(page, "text=用户登录", 120000);
ok("公网可达且加载登录页", !!frame);
if (!frame) {
  await page.screenshot({ path: `${SHOT}_failed_load.png` });
  console.log(results.join("\n"));
  process.exit(1);
}
await page.screenshot({ path: `${SHOT}_0_login.png` });

console.log("== 2. 注册验证账号 ==");
try {
  await frame.locator("text=📝 注册").click({ timeout: 10000 });
  await page.waitForTimeout(2000);
  await frame.getByRole("textbox", { name: "用户名" }).fill(USER);
  await frame.getByRole("textbox", { name: "密码" }).first().fill(PASS);
  // 注册表单可能有确认密码框
  const confirmBox = frame.getByRole("textbox", { name: "确认密码" });
  if ((await confirmBox.count()) > 0) await confirmBox.fill(PASS);
  const emailBox = frame.getByRole("textbox", { name: "邮箱" });
  if ((await emailBox.count()) > 0) await emailBox.fill(`${USER}@test.local`);
  await page.waitForTimeout(5000);
  await frame.getByRole("button", { name: "注册" }).click({ timeout: 15000 });
  await page.waitForTimeout(8000);
  const regOk = (await frame.locator("text=注册成功").count()) > 0
    || (await frame.locator("text=已注册").count()) > 0;
  ok("注册流程可用（提示或后续登录成功为准）", regOk, `账号 ${USER}，最终以登录结果判定`);
  if (!regOk) await page.screenshot({ path: `${SHOT}_0b_register.png` });
} catch (e) {
  ok("注册成功", false, e.message.slice(0, 100));
}

console.log("== 3. 登录 ==");
// 登录前重新定位 frame（注册操作可能触发 rerender）
frame = (await findFrame(page, 'input[type="password"]', 30000)) || frame;
try {
  // 如果还在注册 tab，切回登录
  if ((await frame.locator("text=🔐 登录").count()) > 0) {
    await frame.locator("text=🔐 登录").first().click({ timeout: 8000 });
    await page.waitForTimeout(2000);
  }
  await frame.getByRole("textbox", { name: "用户名" }).fill(USER);
  await frame.getByRole("textbox", { name: "密码" }).fill(PASS);
  await frame.getByRole("button", { name: "登录" }).click({ timeout: 15000 });
} catch (e) {
  // 退回通用定位
  await frame.locator('input[type="text"]').first().fill(USER);
  await frame.locator('input[type="password"]').first().fill(PASS);
  await frame.getByRole("button", { name: "登录" }).click({ timeout: 15000 });
}
await page.waitForTimeout(12000);
// 登录成功的标志：密码框消失，且出现主界面导航
const pwGone = (await frame.locator('input[type="password"]').count()) === 0;
const navSeen = (await frame.locator("text=AI 投研问答").count()) > 0
  || (await frame.locator("text=另类数据仪表盘").count()) > 0;
ok("登录成功（进入主界面）", pwGone && navSeen, `pwGone=${pwGone} navSeen=${navSeen}`);
await page.screenshot({ path: `${SHOT}_1_home.png` });
if (!(pwGone && navSeen)) {
  console.log(results.join("\n"));
  await browser.close();
  process.exit(1);
}

console.log("== 4. AI 投研问答 + 语义对齐前置条 ==");
frame = (await findFrame(page, "text=AI 投研问答", 30000)) || frame;
await frame.locator("text=AI 投研问答").first().click({ timeout: 15000 });
await page.waitForTimeout(6000);
const qaBox = frame.locator("textarea").first();
ok("问答页输入框存在", (await qaBox.count()) > 0);
if ((await qaBox.count()) > 0) {
  await qaBox.fill("贵州茅台最新财报的核心亮点和风险点是什么？");
  await page.waitForTimeout(1000);
  const btn = frame.getByRole("button", { name: "分析" });
  if ((await btn.count()) > 0) await btn.first().click({ timeout: 15000 });
  // 等语义对齐条（最长 90s，LLM 冷启动）
  let alignSeen = false;
  const deadline = Date.now() + 90000;
  while (Date.now() < deadline) {
    if ((await frame.locator("text=语义对齐").count()) > 0) { alignSeen = true; break; }
    await page.waitForTimeout(2000);
  }
  ok("语义对齐前置条出现（5f424b9 新功能）", alignSeen);
  await page.screenshot({ path: `${SHOT}_2_qa_align.png` });
  // 等回答渲染
  await page.waitForTimeout(20000);
  const body = await frame.locator("body").innerText();
  const answered = body.length > 1000
    && (body.includes("🤖") || body.includes("tool_use") || body.includes("分析摘要"));
  ok("AI 问答正常响应（LLM 已开始生成）", answered, `页面文本长度 ${body.length}`);
  await page.screenshot({ path: `${SHOT}_3_qa_answer.png` });
}

console.log("== 5. 核心页巡检 ==");
for (const nav of ["另类数据仪表盘", "量化策略回测"]) {
  try {
    frame = (await findFrame(page, `text=${nav}`, 30000)) || frame;
    await frame.locator(`text=${nav}`).first().click({ timeout: 15000 });
    await page.waitForTimeout(9000);
    const body = await frame.locator("body").innerText();
    const widgets = ["运行回测", "策略类型", "起始日期", "数据源", "语义"];
    const hit = widgets.filter((w) => body.includes(w)).length;
    ok(`页面「${nav}」渲染正常`, body.length > 500 && hit >= 1, `文本长度 ${body.length}，命中控件 ${hit}`);
  } catch (e) {
    ok(`页面「${nav}」渲染正常`, false, e.message.slice(0, 80));
  }
}
await page.screenshot({ path: `${SHOT}_4_final.png` });

console.log("\n===== 验证结果 =====");
console.log(results.join("\n"));
const failed = results.filter((r) => r.startsWith("❌")).length;
console.log(`\n${failed === 0 ? "ALL PASS" : failed + " FAILED"}`);
await browser.close();
process.exit(failed === 0 ? 0 : 1);
